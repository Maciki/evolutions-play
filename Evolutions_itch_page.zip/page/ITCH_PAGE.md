# Evolutions — itch.io page

## Upload settings (Edit game)
- Kind of project: **HTML**
- Upload `Evolutions_itch_web.zip` and tick **This file will be played in the browser**
- Embed options: **Embed in page**, viewport **1280 × 720**
- Tick **Mobile friendly** (orientation: Landscape) and **Fullscreen button**
- Leave **SharedArrayBuffer support** off (the game is built without threads)
- Cover image: `cover_630x500.png` · Screenshots: `screenshot_1..6.png`
- Genre: Action · Tags: pixel-art, evolution, roguelite, monsters, singleplayer, thai

## Short description
Eat. Fight. Evolve. Start as a tiny blob and devour your way to a world-ending monster.

## Description (EN)
Before time was counted, the Primeval Devourer swallowed the world and left a shard of its hunger in every land.
In a forgotten warm pool, one tiny spark opens its eyes… you.

- **Eat what's smaller, flee what's bigger.** Every bite feeds your DNA.
- **57 evolution forms** across four paths: Fang, Stone, Venom and Arcane, with branches in between.
- **11 hand-drawn pixel-art lands**, 45 creatures and 11 bosses.
- **Mutations** from what you eat: horns, extra eyes, crystal skin and more.
- **A story told in cutscenes**, from the first hunger to the last bite.
- Thai and English, keyboard or touch.

Controls: WASD / arrows to move · bite automatically by touching prey · Q E R skills · Esc pause

## คำอธิบาย (TH)
ก่อนกาลเวลาจะถูกนับ อสูรกลืนกาลปฐมกลืนโลกจนสิ้น และทิ้งเศษความหิวไว้ในทุกดินแดน
ในบ่อน้ำอุ่นที่ถูกลืม ประกายเล็กจิ๋วดวงหนึ่งลืมตาขึ้น… นั่นคือเจ้า

- **กินตัวที่เล็กกว่า หนีตัวที่ใหญ่กว่า** ทุกคำที่กินคือ DNA
- **57 ร่างวิวัฒนาการ** 4 สาย: เขี้ยวโลหิต · เกราะศิลา · พิษมรณะ · มนตรา พร้อมสายลูกผสม
- **11 ดินแดน** ภาพพิกเซลอาร์ตทั้งหมด สัตว์ 45 ชนิด บอส 11 ตัว
- **การกลายพันธุ์** จากสิ่งที่กิน: เขา ดวงตาพิเศษ ผิวคริสตัล และอื่นๆ
- **เนื้อเรื่องผ่านคัตซีน** ตั้งแต่ความหิวแรกจนถึงคำสุดท้าย
- ภาษาไทยและอังกฤษ เล่นได้ทั้งคีย์บอร์ดและจอสัมผัส

ควบคุม: WASD / ลูกศร เดิน · เข้าใกล้เหยื่อเพื่อกัดอัตโนมัติ · Q E R สกิล · Esc หยุดเกม

## Theme (Edit theme panel)
| Field | Value |
|---|---|
| BG | `#08060d` |
| BG 2 | `#14101e` |
| Text | `#f2eee0` |
| Link | `#8cf272` |
| Headers | `#8cf272` |
| Buttons | `#6b3fa0` |
| BG2 Alpha | about 85% |
| Font | Lato (or Pixelify Sans if listed) · Size: Large |
| Header font | Pixelify Sans / Press Start 2P if listed, else Default |
| Screenshots | Sidebar |
| Banner | `banner_960x300.png` |
| Background | `background_1920x1080.png` · Don't repeat · Position: top center |
| Embed BG | `embed_bg_1280x720.png` |
